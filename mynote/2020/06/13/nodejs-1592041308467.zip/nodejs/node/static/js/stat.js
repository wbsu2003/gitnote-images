/**
 * Created by hanrb on 2016/2/25.
 */

var href_nodejs_online = "http://127.0.0.1:3000/";//123.57.58.230
var front_sessionid = "";
try{
    front_sessionid = _sessionId;
}catch (e) {
    console.log(e);
}

var socket_nodejs_online = io(href_nodejs_online,{ query: "sessionid="+front_sessionid });
window.onbeforeunload = function(){
    socket_nodejs_online.emit("leave",function(){});
}


socket_nodejs_online.on("front_logout",function(){
    try{
        refrenshPage();
    }catch (e) {
        console.log(e);
    }

});