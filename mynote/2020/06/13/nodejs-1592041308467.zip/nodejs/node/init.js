/**
 * Created by hanrb on 2016/1/8.
 */

var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);

var path = require('path');

app.get('/api/front/logout', function(req, res){
    var sessionid = req.query.sessionid;
    io.sockets.to(sessionid).emit("front_logout");
    res.writeHead(200, {'Content-Type': 'application/json;charset=utf-8'});
    res.end("ok");
});
app.get('/api/getdomain', function(req, res){
    var companyId = req.query.companyId;

    res.writeHead(200, {'Content-Type': 'application/json;charset=utf-8'});
    res.end("http://127.0.0.1:3000");
});
module.exports = app;

app.use("/static", express.static(__dirname + "/static"))

var online ={};
online.method = {
    connection:function(){
        io.on('connection', function(socket){
            socket.on("leave",function(){
                socket.disconnect();
            });
            //front sessionid
            var sessionid = socket.handshake.query.sessionid;
            //加入channel
            if(sessionid!=null && sessionid!=""){
                socket.join(sessionid);
            }
        });
    }
};
online.method.connection();

http.listen(3000, function(){
    console.log('listening on *:3000');

});