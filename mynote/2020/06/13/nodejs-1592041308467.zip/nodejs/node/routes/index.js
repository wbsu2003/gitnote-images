var express = require('express');
var router = express.Router();

var redis = require("redis");

//var redisDb  = redis.createClient(config.config.reids.port,config.config.reids.host,{});
//redisDb.auth(config.config.reids.password,function(){});
//console.log(config)
console.log(module.exports.app)
router.get('/getCompanyInfo', function(req, res, next) {
    //redisDb.hgetall("online.company.domain",function(err,data){
    //    res.render('index', { title: data
    //
    //    });
    //});
});

module.exports = router;
